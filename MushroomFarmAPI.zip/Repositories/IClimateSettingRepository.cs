﻿using MushroomFarmAPI.Models;

namespace MushroomFarmAPI.Repositories
{
    public interface IClimateSettingRepository : IRepository<ClimateSetting>
    {
        // ClimateSetting'e özgü ek metotlar burada tanımlanabilir.
    }
}

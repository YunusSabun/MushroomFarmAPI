﻿using MushroomFarmAPI.Models;

namespace MushroomFarmAPI.Repositories
{
    public interface IRoomRepository : IRepository<Room>
    {
        // Room'a özgü ek metotlar burada tanımlanabilir.
    }
}

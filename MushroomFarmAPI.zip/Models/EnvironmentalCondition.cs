﻿namespace MushroomFarmAPI.Models
{
    public class EnvironmentalCondition
    {
        public int Id { get; set; }
        public float Temperature { get; set; }
    }
}

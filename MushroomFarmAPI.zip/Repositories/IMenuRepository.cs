﻿using MushroomFarmAPI.Models;

namespace MushroomFarmAPI.Repositories
{
    public interface IMenuRepository : IRepository<Menu>
    {
        // Menu'ye özgü ek metotlar burada tanımlanabilir.
    }
}

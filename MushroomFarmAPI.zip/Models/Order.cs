﻿namespace MushroomFarmAPI.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Supplier { get; set; }
    }
}

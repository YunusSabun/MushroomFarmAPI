﻿namespace MushroomFarmAPI.Models
{
    public class TaskMasterData
    {
        public int Id { get; set; }
        public string? TaskName { get; set; }
        public string? Description { get; set; }
    }
}

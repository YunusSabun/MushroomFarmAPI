﻿namespace MushroomFarmAPI.Models
{
    public class EmployeeType
    {
        public int Id { get; set; }
        public string? TypeName { get; set; }
    }
}
